#ifndef LOG_LEVELS
#define LOG_LEVELS

enum log_level
{
    debug,
    trace,
    info,
    warning,
    error
}

#endif
